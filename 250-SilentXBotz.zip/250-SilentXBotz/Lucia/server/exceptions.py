class InvalidHash(Exception):
    message = "Invalid Hash"

class FIleNotFound(Exception):
    message = "File Not Found"
